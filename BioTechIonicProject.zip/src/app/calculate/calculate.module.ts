import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CalculateRoutingModule } from './calculate-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CalculateRoutingModule
  ]
})
export class CalculateModule { }
