import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ShowMsgRoutingModule } from './show-msg-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ShowMsgRoutingModule
  ]
})
export class ShowMsgModule { }
