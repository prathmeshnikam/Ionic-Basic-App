import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-msg',
  templateUrl: './add-msg.component.html',
  styleUrls: ['./add-msg.component.scss'],
})
export class AddMsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
